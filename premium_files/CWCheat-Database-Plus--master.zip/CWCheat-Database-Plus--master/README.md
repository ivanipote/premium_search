# CWCheat-Database-Plus-
Cheat Database for PPSSPP/PSP
ฐานข้อมูลสูตร สำหรับอีมูเลเตอร์ PPSSPP และเครื่อง PSP

# Download. (เวอร์ชั่นล่าสุดอยู่เสมอ)

<a href="https://github.com/Saramagrean/CWCheat-Database-Plus-/archive/master.zip">Click Here... </a>

<a href="https://ibb.co/2ZzpVMn"><img src="https://i.ibb.co/mNnPZyD/CWCheat-0.jpg" alt="CWCheat-0" border="0"></a>

========================================================================

# Original Thread. (เว็บฐานข้อมูลสูตรต้นฉบับ)
https://forums.ppsspp.org/showthread.php?tid=11961

# Special Thanks. (ขอบคุณเป็นพิเศษ)

<a href="https://forums.ppsspp.org/forumdisplay.php?fid=31"> PPSSPP Forum (CWCheat codes) </a>

<a href="https://gamehacking.org/system/psp/all"> GameHacking </a> (รวมสูตรเกม PSP)

<a href="https://github.com/LunaMoo/PPSSPP_workarounds"> LunaMoo </a> (รวมสูตรแก้ไขปัญหา/เพิ่มประสิทธิภาพ/ช่วยควบคุม)

<a href="http://forums.ppsspp.org/showthread.php?tid=22787"> Kabuto_Kun </a> (รวมสูตรแก้ไขปัญหา/เพิ่มประสิทธิภาพ/ช่วยควบคุม)

<a href="https://github.com/TAbdiukov/PPSSPP-patches"> TAbdiukov </a> (รวมสูตรเพิ่มประสิทธิภาพ/ช่วยควบคุม)

<a href="http://forums.ppsspp.org/showthread.php?tid=22800"> 60 FPS Patch </a> (รวมสูตร 60 FPS)

<a href="https://forums.ppsspp.org/showthread.php?tid=26189"> Widescreen Patches </a> (รวมสูตรปรับภาพเต็มจอสำหรับหน้าจอกว้าง)

<a href="[https://forums.ppsspp.org/forumdisplay.php?fid=31](https://raing3.gshi.org/psp-utilities/#!/code-archive/)"> Raing3 Code Archive </a> (โค้ดต้นฉบับจากที่นี่ใช้ไม่ได้ ต้องแปลงกลับมาเป็น CWCheat อีกที) :

...และตามเว็บรวมโค้ดสูตรเกม PSP อื่นๆ ที่ไม่ได้กล่าวถึง :)
